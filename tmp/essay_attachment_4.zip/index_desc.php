<?
session_start();
require_once('ci.index.php');
include (ROOTPATH.'conn.php');

$queryStr = $_SERVER['QUERY_STRING'];
$explo = explode('&', $queryStr);
$queryString = $explo['1'];
$community   = $explo['0'];
?>
	
<link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
<script type="text/javascript" src ="js/jquery-1.9.1.js"></script>
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
<script type="text/javascript" src="jquery.timepicker.js"></script>
<link rel="stylesheet" type="text/css" href="jquery.timepicker.css" />
<link rel="stylesheet" href="/resources/demos/style.css">

<link rel="stylesheet" type="text/css" href="css/style.css" />

	<title>Britshield Guest Profile</title>
	<script type="text/javascript">
		$(document).ready(function(){
			
			$('#VENStartDate').hover(function(){
				$("#VENStartDate").datepicker();
			});
			
			$('#VENEndDate').hover(function(){
				$("#VENEndDate").datepicker();
			});
		});	
		
		// FUNCTION FOR SEARCH------------------------
		
		function selectName(str)
		{
			$.ajax({
				type: "POST",
				url: "search.php",
				data: 'str='+str,
				context: document.body
				}).done(function(result){
					$('.Kio_logForm').hide();
					$('.Kio_ADDForm').hide();
					$('#search_detailsAll').html(result);
				});
			return false;
		}
		
		//---SHOW ADD GUEST FORM--------------------------
	
		function ShowADDGUESTForm(str)
		{
			$('#residentCode').val(str);
			$('.Kio_logForm').hide();
			$('.Kio_ADDForm').show();
			$('.Kio_ADDVendorForm').hide();
			$('.Kio_VendorlogForm').hide();
		}
		
		//----FOR LOGS FORM----------------------------
			
			function ShowLogForm()
			{
				$('.Kio_logForm #log_fname').val('');
				$('.Kio_logForm #log_lname').val('');
				$('.Kio_logForm #log_tag').val('');
				$('.Kio_ADDVendorForm').hide();
				$('.Kio_ADDForm').hide();
				$('.Kio_VendorlogForm').hide();
				$('.Kio_logForm').show();
			}

		//---FOR VENDOR LOG FORM-----------------------------
			function ShowVendorLogForm()
			{
				$('.Kio_VendorlogForm #VendorCompany').val('');
				$('.Kio_VendorlogForm #VendorRepresentative').val('');
				$('.Kio_VendorlogForm #log_tag').val('');
				$('.Kio_ADDVendorForm').hide();
				$('.Kio_ADDForm').hide();
				$('.Kio_logForm').hide();
				$('.Kio_VendorlogForm').show();
			}
			
			function ShowVendorLogFormByName(str)
			{
				var myArray = str.split('-');
				$('.Kio_VendorlogForm #VendorCompany').val(myArray['0']);
				$('.Kio_VendorlogForm #VendorRepresentative').val(myArray['1']);
				$('.Kio_VendorlogForm').show();
				$('.Kio_ADDVendorForm').hide();
				$('.Kio_ADDForm').hide();
				$('.Kio_logForm').hide();
			}
			
		//----VENDOR LOG VALIDATION------------
			function vendorLogForm()
			{
				var a = $('#VendorCompany').val();
				var b = $('#VendorRepresentative').val();
				if(a == '' || b == '')
				{
					$('#vendorLogError').html('All Fields Are Required');
					return false;
				}
				else
				{
					$('.Kio_VendorlogForm #VendorCompany').val('');
					$('.Kio_VendorlogForm #VendorRepresentative').val('');
					$('.Kio_VendorlogForm #log_tag').val('');
					$('.Kio_ADDVendorForm').hide();
					$('.Kio_ADDForm').hide();
					$('.Kio_logForm').hide();
					$('.Kio_VendorlogForm').hide();
					return false;
				}
			}
			
		//----FOR LOGS FORM FROM NAME CLICK----------------------------
			
			function ShowLogFormByName(str)
			{
				var myArray = str.split('-');
					
					$('.Kio_logForm #log_fname').val(myArray['0']);
					$('.Kio_logForm #log_lname').val(myArray['1']);
					/*if(myArray['2'] == '')
					{
						$('.Kio_logForm #log_tag').val(' ');
					}
					else
					{
						$('.Kio_logForm #log_tag').val(myArray['2']);
					}*/
				
				$('.Kio_ADDForm').hide();
				$('.Kio_logForm').show();
			}		
		
		//------FOR GUEST LOG FORM----------------------------------
	
		function guestLogForm()
		{
			
			var fname = $('#log_fname').val();
			var lname = $('#log_lname').val();
			var log_vehicle_make = $('#log_vehicle_make').val();
			var log_vehicle_color = $('#log_vehicle_color').val();
			var tag   = $('#log_tag').val();
						
			if(fname == '' || lname == '' || log_vehicle_make == '' || log_vehicle_color == '')
			{
				$('#guestLogError').html("All Fields Are Required.");
				return false;
			}
			else
			{
				$('#guestLogError').val('');
				$('#log_fname').val('');  //field empty
				$('#log_lname').val(''); //field empty
				$('#log_tag').val('');  //field empty
				
				$('.Kio_logForm').hide();
				$('.Kio_ADDForm').hide();
				$('.Kio_ADDVendorForm').hide();
				return false;
			}
		}
	
	//---FUNCTION TO DELETE GUESTS-------------
		
		function DeleteGuest(str,res)
		{
			//alert(str+'--'+res); return false;
			$.ajax({
				type: "POST",
				url: "deleteGuest.php",
				data: 'str='+str+'='+res,
				context: document.body
				}).done(function(result){
				//alert(result); return false;
					$('#guestADDError').html("");
					$('#add_fname').val('');
					$('#add_lname').val('');
					$('#residentCode').val('');
					$('#StartDate').val('');
					$('#EndDate').val('');
					$('.Kio_logForm').hide();
					$('.Kio_ADDForm').hide();
					$('.allRECORDS #thirdDivTable').html(result);
					$('#MYsuccessMessage').show();
					$('#MYsuccessMessage').html('Guest Deleted Successfully');
					setTimeout(function() {
						$('#MYsuccessMessage').fadeOut('slow');
					}, 3000);
				});
			return false;
		}

		
		//---FUNCTION TO ADD GUEST------------
	
		function guestADDForm()
		{
			var fname      = $('#add_fname').val();
			var lname      = $('#add_lname').val();
			var residentID = $('#residentCode').val();

			var d = new Date();
			var month = d.getMonth()+1;
			var day = d.getDate();
			var output = (month<10 ? '0' : '') + month + '/' +(day<10 ? '0' : '') + day+ '/' +d.getFullYear();
			
			var StartDate  = output;
			var EndDate    = "";
			
			if(fname == '' || lname == '')
			{
				$('#guestADDError').html("All Fields Are Required.");
				return false;
			}
			else
			{
				$.ajax({
				type: "POST",
				url: "addGuest.php",
				data: 'residentID='+residentID+'&fname='+fname+'&lname='+lname+'&startdate='+StartDate+'&enddate='+EndDate,
				context: document.body
				}).done(function(result){
					$('#guestADDError').html("");
					$('#add_fname').val('');
					$('#add_lname').val('');
					$('#residentCode').val('');
					$('#StartDate').val('');
					$('#EndDate').val('');
					$('.Kio_logForm').hide();
					$('.Kio_ADDForm').hide();
					$('.Kio_ADDVendorForm').hide();
					$('.allRECORDS #thirdDivTable').html(result);
					$('#MYsuccessMessage').html('Guest Added Successfully');
					setTimeout(function() {
						$('#MYsuccessMessage').fadeOut('slow');
					}, 3000);
				});
				return false;
			}
		}
		
		//---SHOW ALL ENTRIES----------------------
		
		function viewAllEntries(str)
		{
			$('.Kio_ADDVendorForm').hide();
			$('.Kio_ADDForm').hide();
			$('.Kio_logForm').hide();
			$.ajax({
				type: "POST",
				url: "viewEntries.php",
				data: 'residentId='+str,
				context: document.body
				}).done(function(result){
					if(result == '0')
					{
						alert('Nothing found');
					}
					else
					{
						$('#log_fname').val('');
						$('#log_lname').val('');
						$('#log_tag').val('');
						$('.ShowSeatinG').show();
						$('.ShowSeatinG .PlaceHtml').html('<div class="info_sheet_form_title" style="margin-left:41%">Guest Entries</div>'+result);
					}
				});
		}
		
		//-----CLOSE THE POP_UP-------------------

		function closeMe()
		{
			$('.ShowSeatinG .PlaceHtml').html("");
			$('.ShowSeatinG').hide();
		}
		
		//---Select Top Searchj Div function----------------
		
		function SelSearch(str)
		{
			if(str == 'Resident')
			{
				$('#selCommunity').val('1');
				$('#change_TITLE').html('Search Resident Guests');
				$('#FIRSt').show();
				$('#SECONd').hide();
					$('.Kio_right #fname').val('');
					$('.Kio_right #lname').val('');
					$('.Kio_right #phone').val('');
					$('.Kio_right #address').val('');
					$('.Kio_right #tag').val('');
						$('#SECONd #GUESTfname').val('');
						$('#SECONd #GUESTlname').val('');
						$('#SECONd #GUESTtag').val('');
					$('.Kio_left .allRECORDS').html('No Records Found');
						$('.Kio_logForm').hide();
						$('.Kio_VendorlogForm').hide();
						$('.Kio_ADDForm').hide();
						$('.Kio_ADDVendorForm').hide();
			}
			else if(str == 'Visitor')
			{
				$('#SECONd #GUESTselCommunity').val('2');
				$('#SECONd #change_TITLE').html('Search Visitors');
				$('#FIRSt').hide();
				$('#SECONd').show();
					$('.Kio_right #fname').val('');
					$('.Kio_right #lname').val('');
					$('.Kio_right #phone').val('');
					$('.Kio_right #address').val('');
					$('.Kio_right #tag').val('');
						$('#SECONd #GUESTfname').val('');
						$('#SECONd #GUESTlname').val('');
						$('#SECONd #GUESTtag').val('');
					$('.Kio_left .allRECORDS').html('No Records Found');
						$('.Kio_logForm').hide();
						$('.Kio_VendorlogForm').hide();
						$('.Kio_ADDForm').hide();
						$('.Kio_ADDVendorForm').hide();
			}
			else if(str == 'Vendor')
			{
				$('#selCommunity').val('3');
				$('#change_TITLE').html('Search Vendor List');
				$('#FIRSt').show();
				$('#SECONd').hide();
					$('.Kio_right #fname').val('');
					$('.Kio_right #lname').val('');
					$('.Kio_right #phone').val('');
					$('.Kio_right #address').val('');
					$('.Kio_right #tag').val('');
						$('#SECONd #GUESTfname').val('');
						$('#SECONd #GUESTlname').val('');
						$('#SECONd #GUESTtag').val('');
					$('.Kio_left .allRECORDS').html('No Records Found');
						$('.Kio_logForm').hide();
						$('.Kio_VendorlogForm').hide();
						$('.Kio_ADDForm').hide();
						$('.Kio_ADDVendorForm').hide();
			}
		}
	//---SEARCH ROM TOP FORM ALL--------------	
		function searchAll()
		{
			$('.Kio_ADDVendorForm').hide();
			$('.Kio_logForm').hide();
			$('.Kio_ADDForm').hide();
			$('.Kio_VendorlogForm').hide();
			
			var community = $('#selCommunity').val();
			var fname     = $('#fname').val();
			var lname     = $('#lname').val();
			var phone     = $('#phone').val();
			var address   = $('#address').val();
			var tag       = $('#tag').val();
			
			if(fname == "" && lname == "" && phone == "" && address == "" && tag == "")
			{
				$('#ReqFields').html("Please Fill Any One Field To Search");
				$(".allRECORDS").html("<b style='float: left; width: 100%; text-align: center; font-size: 18px;'>No Record Found.</b>");
				return false;
			}
			else
			{
				$.ajax({
				type: "POST",
				url: "searchForNotFound.php",
				data: 'community='+community+'&fname='+fname+'&lname='+lname+'&phone='+phone+'&address='+address+'&tag='+tag+'&SelCommunity='+<?php echo $community; ?>,
				context: document.body
				}).done(function(result){
					//alert(result);
					//return false;
					if(result == '0' || result == 'null')
					{
						$(".allRECORDS").html("<b style='float: left; width: 100%; text-align: center; font-size: 18px;'>No Record Found.</b>");
					}
					else
					{	
						$(".allRECORDS").html(result);
					}
				});
				return false;
			}
		}
	
	//---SEARCH FOR VISITOR------------------------------------------
		function searchVisitor()
		{
			$('.Kio_ADDVendorForm').hide();
			$('.Kio_logForm').hide();
			$('.Kio_ADDForm').hide();
			$('.Kio_VendorlogForm').hide();
			
			var GUESTselCommunity = $('#GUESTselCommunity').val();
			var GUESTfname        = $('#GUESTfname').val();
			var GUESTlname        = $('#GUESTlname').val();
			var GUESTtag          = $('#GUESTtag').val();
			
			if(GUESTfname == "" && GUESTlname == "" && GUESTtag == "")
			{
				$('#SECONd #GUESTReqFields').html("Please Fill Any One Field To Search");
				return false;
			}
			else
			{
				$.ajax({
				type: "POST",
				url: "searchForVisitor.php",
				data: 'GUESTfname='+GUESTfname+'&GUESTlname='+GUESTlname+'&GUESTtag='+GUESTtag,
				context: document.body
				}).done(function(result){
					//alert(result);
					//return false;
					if(result == '0' || result == 'null')
					{
						$(".allRECORDS").html("<b style='float: left; width: 100%; text-align: center; font-size: 18px;'>No Record Found.</b>");
					}
					else
					{	
						$(".allRECORDS").html(result);
					}
				});
				return false;
			}
		}
	
	
	//--SHOW ADD VENDOR FORM---------------
		
		function ShowADDVendorForm(str)
		{
			$('#VENresident_code').val(str);
			$('.Kio_ADDVendorForm').show();
			$('.Kio_ADDForm').hide();
			$('.Kio_logForm').hide();
			$('.Kio_VendorlogForm').hide();
		}
		
	//--FOR ADD VENDOR FORM-----------------

		function VendorValidation()
		{
			var VENresident_code       = $('#VENresident_code').val();
			var VENcompany_name        = $('#VENcompany_name').val();
			var VENrepresentative_name = $('#VENrepresentative_name').val();
			var VENrepresentative_id   = $('#VENrepresentative_id').val();
			var VENStartDate           = $('#VENStartDate').val();
			var VENEndDate             = $('#VENEndDate').val();
			var VENaccess_privileges   = $('#VENaccess_privileges').val();
			
			if(VENcompany_name == '' || VENrepresentative_name == '' || VENrepresentative_id == '' || VENStartDate == '' || VENEndDate == '' || VENaccess_privileges == '' || VENaccess_privileges == 'null')
			{
				$('#errorVendoR').html('All Fields Are Required');
				return false;
			}
			else
			{
				if (VENrepresentative_id != VENrepresentative_id.replace(/[^0-9\.]/g, ''))
				{
					$('#errorVendoR').html('');
					$('#err_representative_id').html('Please Use Only Integers For Representative Id.');
					return false;	
				}
				
				$.ajax({
				type: "POST",
				url: "addVendor.php",
				data: 'VENresident_code='+VENresident_code+'&VENcompany_name='+VENcompany_name+'&VENrepresentative_name='+VENrepresentative_name+'&VENrepresentative_id='+VENrepresentative_id+'&VENStartDate='+VENStartDate+'&VENEndDate='+VENEndDate+'&VENaccess_privileges='+VENaccess_privileges,
				context: document.body
				}).done(function(result){
					//alert(result);
					//return false;
					if(result == '0' || result == 'null')
					{
						$(".allRECORDS").html("<b style='float: left; width: 100%; text-align: center; font-size: 18px;'>No Record Found.</b>");
					}
					else
					{
						$(".allRECORDS #thirdDivTable").html(result);
						$('.Kio_ADDVendorForm').hide();
						$('#VENresident_code').val('');
						$('#VENcompany_name').val('');
						$('#VENrepresentative_name').val('');
						$('#VENrepresentative_id').val('');
						$('#VENStartDate').val('');
						$('#VENEndDate').val('');
						$('#VENaccess_privileges').val('');
						$('#MYsuccessMessage').html('Vendor Added Successfully');
						setTimeout(function() {
							$('#MYsuccessMessage').fadeOut('slow');
						}, 3000);
					}
				});
				return false;
			}
		}
		
	//----VIEW ALL VENDOR LIST ENTRIES-----------------------------------------
		
		function viewAllVendorEntries(str)
		{
			$('.Kio_ADDVendorForm').hide();
			$('.Kio_ADDForm').hide();
			$('.Kio_logForm').hide();
			$.ajax({
				type: "POST",
				url: "viewVendorEntries.php",
				data: 'residentId='+str,
				context: document.body
				}).done(function(result){
					if(result == '0')
					{
						alert('Nothing found');
					}
					else
					{
						$('#log_fname').val('');
						$('#log_lname').val('');
						$('#log_tag').val('');
						$('.ShowSeatinG').show();
						$('.ShowSeatinG .PlaceHtml').html('<div class="info_sheet_form_title" style="margin-left:41%">Vendor Entries</div>'+result);
					}
				});
		}
		
	</script>
		
	<?php include('header.php'); ?>

		<div class="body_container">
		
			<nav>
				<ul>
					<li style="margin-left:7%;">
						<a style="margin-right:10px;" href="<?php echo WWWPATH.'/koisk_module/tag_page.php?'.$community."&sec=".$queryString;?>">
							BACK
						</a>
						<a href="<?php echo WWWPATH.'/koisk_module/index.php?'.$queryString;?>">
							HOME
						</a>
					</li>
				</ul>
			</nav>
			<div style="float:left; width:100%">
				<select onchange="SelSearch(this.value)" name="topSelect" id="topSelect" style="float: left; border-radius: 0px; border: 1px solid #c3c3c3; width: 7%; margin: 0px 0px 0px 2%;">
					<option value="">Search</option>
					<option value="Resident" value="Resident" >Resident</option>
					<option value="Visitor"  value="Visitor">Visitor</option>
					<option value="Vendor"   value="Vendor">Vendor</option>
				</select>
			</div>
			<div class="Kio_right" id="FIRSt" style="float: left; width: 32%; margin: 6px 0px 0px 33%; display:none;">
				<div class="form_title" id="change_TITLE" style="margin:0 0 0 32%;">Search</div>

				<p id="ReqFields" style="float: left; width: 100%; text-align: center; color: maroon; font-weight: bold; font-size:15px;"></p> <!-- Show Required fields error -->
				<p id="SelectedCommunity"></p> <!-- Show Selected Community -->
				
				<form action="#" method="post" onsubmit="return searchAll();">
					<input type="hidden" name="selCommunity" id="selCommunity" value=""/>
					<input type="text" name="fname" id="fname" placeholder="First Name"/>
					<input type="text" name="lname" id="lname" placeholder="Last Name"/>
					<input type="text" name="phone" id="phone" placeholder="Phone"/>
					<input type="text" name="address" id="address" placeholder="Address"/>
					<input type="text" name="tag" id="tag" placeholder="Tag"/>
					<input type="submit" value="Search" style="padding:2px 0px 3px 0;"/>
				</form>
			</div>
			
			<div class="Kio_right" id="SECONd" style="float: left; width: 32%; margin: 6px 0px 0px 33%; display:none;">
				<div class="form_title" id="change_TITLE" style="margin:0 0 0 32%;">Search</div>

				<p id="GUESTReqFields" style="float: left; width: 100%; text-align: center; color: maroon; font-weight: bold;"></p> <!-- Show Required fields error -->
				<p id="SelectedCommunity"></p> <!-- Show Selected Community -->
				<form id="SECONd" action="#" method="post" onsubmit="return searchVisitor();">
					<input type="hidden" name="GUESTselCommunity" id="GUESTselCommunity" value=""/>
					<input type="text" name="GUESTfname" id="GUESTfname" placeholder="Guest First Name"/>
					<input type="text" name="GUESTlname" id="GUESTlname" placeholder="Guest Last Name"/>
					<input type="text" name="GUESTtag" id="GUESTtag" placeholder="Guest Tag"/>
					<input type="submit" value="Search" style="padding:2px 0px 3px 0;"/>
				</form>
			</div>
			<div class="Kio_left" style="margin:33px 0 0 33%; width:32%;">
				<div style="margin: 0px 0px 10px 0%; width: 100%; float: left;" class="form_title">
				Search Details
				</div>
				<div class="allRECORDS" style="float:left; width:100%; text-align:center; font-weight:bold; padding-bottom:20px;">
					No Records Found
					<div id="search_detailsAll"></div>
				</div>
			</div>
	
	<!----------LOG FORM ---------------------------------------------------------->
	
			<div class="Kio_logForm" style="display:none;">
				<div id="res_head">Guest Log Form</div>
				<span id="guestLogError"></span>
				<form action="#topSide" id="SearchFromz22" method="post" onsubmit="return guestLogForm();">
					<div class="new1">
						<input type="text" name="log_fname" id="log_fname" placeholder="First Name"/>
					</div>
					
					<div class="new1">
						<input type="text" name="log_lname" id="log_lname" placeholder="Last Name"/>
					</div>
					
					<div class="new1">
						<input type="text" name="log_vehicle_make" id="log_vehicle_make" placeholder="Vehicle Make"/>
					</div>
					
					<div class="new1">
						<input type="text" name="log_vehicle_color" id="log_vehicle_color" placeholder="Vehicle Color"/>
					</div>
					
					<div class="new1">
						<input type="text" name="log_tag" id="log_tag" placeholder="Tag"/>
					</div>
					
					<input type="submit" name="sub" value="Submit"/>
				</form>
			</div>
			
	<!----------VENDOR LOG FORM ----------------------------------------------------->
	
			<div class="Kio_VendorlogForm" style="display:none;">
				<div id="res_head">Vendor Log Form</div>
				<span id="vendorLogError"></span>
				<form action="#topSide" id="SearchFromz22" method="post" onsubmit="return vendorLogForm();">
					<div class="new1">
						<input type="text" name="VendorCompany" id="VendorCompany" placeholder="Vendor Company"/>
					</div>
					
					<div class="new1">
						<input type="text" name="VendorRepresentative" id="VendorRepresentative" placeholder="Vendor Representative"/>
					</div>
					<input type="submit" name="sub" value="Submit" style="width:20%;"/>
				</form>
			</div>
	
	<!------------------ ADD GUEST FORM -------------------------------------------->
			<div class="Kio_ADDForm" style="display:none;">
				<div id="res_head">Add Guest</div>
				<span id="guestADDError"></span>
				<form action="#" id="SearchFromz12" method="post" onsubmit="return guestADDForm();">
					<input type="hidden" name="residentCode" id="residentCode" value=""/>
					<div class="new1">
						<input type="text" name="add_fname" id="add_fname" placeholder="First Name"/>
					</div>
					<div class="new1">
						<input type="text" name="add_lname" id="add_lname" placeholder="Last Name"/>
					</div>
					<input type="submit" name="sub" value="Submit"/>
				</form>
			</div>
		
		<!------------------ ADD Vendor FORM -------------------------------------------->
			<div class="Kio_ADDVendorForm" style="display:none; float: left; background: #fff; margin: 34px 0px 0px 16px; width: 386px;">
				<span id="guestADDError"></span>
				<div id="res_head" style= "background: #d3d3d3;float: left; font-weight: bold; text-align: center; width: 100%; margin:0px 0 10px 0; padding:6px 0;">Add Vendor</div>
<div class="form_outer1">
	<form name="frm_vendor_list" id="frm_vendor_list" method="post" onSubmit="return VendorValidation()">
	<p id="errorVendoR" style="float: left; width: 100%; text-align: center; margin: 0px 0px 6px; color: maroon; font-weight: bold;"></p>
		
		<input type="hidden" name="VENresident_code" id="VENresident_code"/>
		
		<div class="form_row"><label>Company Name:</label><input type="text" id="VENcompany_name" name="VENcompany_name" value="<?=@$arrdata->vendor_list_company_name;?>"/><label>&nbsp;</label><span id="err_company_name" class="error"></span></div>
		<div class="form_row"><label>Representative Name:</label><input type="text" id="VENrepresentative_name" name="VENrepresentative_name" value="<?=@$arrdata->vendor_list_representative_name;?>"/><label>&nbsp;</label><span id="err_representative_name" class="error"></span></div>
		<div class="form_row"><label>Representative ID#:</label><input type="text" id="VENrepresentative_id" name="VENrepresentative_id" value="<?=@$arrdata->vendor_list_representative_id;?>"/>
		<span id="err_representative_id" class="error" style="float: right; font-size: 14px; margin: 0; text-align: center; width: 100%;"></span>
		<label>&nbsp;</label>
		</div>
		
		<div class="form_row"><label>Start Date:</label>
			<input readonly type="text" name="VENStartDate" id="VENStartDate" />
		<label>&nbsp;</label><span id="err_vandor_start" class="error"></span></div>
		
		<div class="form_row"><label>End Date:</label>
			<input readonly type="text" name="VENEndDate" id="VENEndDate" />
		<label>&nbsp;</label><span id="err_vandor_end" class="error"></span></div>

		
		<div class="form_row"><label>Access Privileges:</label>
			<select id="VENaccess_privileges" name="VENaccess_privileges" class="select_width">
				<option value="Permanent">Permanent</option>
				<option value="Day Only" >Day Only</option>
				<option value="Night Only">Night Only</option>
				<option value="Weekdays" >Weekdays</option>
				<option value="Weekends" >Weekends</option>
			</select>
			<label>&nbsp;</label><span id="err_access_privileges" class="error"></span>
		</div>
		<div class="form_row"><label>&nbsp;</label>
		<input type="submit" name="submit" value="Submit" class="signin submit"></div>
	</form>
</div>
			</div>
		
		</div>
	</div>
	
		<!---SHOW VIEW ENTRIES---->
	
	<div class="ShowSeatinG" style="display:none;">
	<div class="bModal __bPopup1" style="background-color: rgb(0, 0, 0); height: 100%; left: 0px; opacity: 0.7; position: fixed; top: 0px; width: 100%; z-index: 9998; cursor: pointer;"></div>
	<div id="warning_message_popup" class="resident_information_popup" style="position: absolute; top: 40%; z-index: 9999; display: block; width: 76%; left: 125px;">
	<a class="bClose" onclick="return closeMe()">x</a>
	<div id="print_log_guest_content" class="log_guest_content" style="width:100%; float:left;">
	
	<button onclick=printContents=document.getElementById('print_pass').innerHTML;originalContents=document.body.innerHTML;document.body.innerHTML=printContents;window.print();document.body.innerHTML=originalContents; style="background:#c3c3c3;
    border: 3px solid #444444; float: left; font-weight: bold; margin: 23px 0 11px 12px; padding: 3px 9px; cursor:pointer;">
		Print
	</button>
	
	<div class="info_sheet_form_outer"style="max-height:434px;">
		<div id="print_pass"  class="PlaceHtml"style="float: left; width: 100%; overflow-y: scroll; height: 366px;"></div>
	</div>
	</div>
	</div>
	</div>
</body>
<?php include('footer.php'); ?>
</html>